from timelines import db

db.create_all()
