DB_FILE='test.db'
DB_STRING = 'sqlite:///' + DB_FILE

